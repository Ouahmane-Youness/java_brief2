create view v_agent_statistics
            (id_agent, nom, prenom, email, type_agent, departement, total_paiements, total_montant, montant_moyen,
             montant_max, montant_min)
as
SELECT a.id_agent,
       a.nom,
       a.prenom,
       a.email,
       a.type_agent,
       d.nom                                AS departement,
       count(p.id_paiement)                 AS total_paiements,
       COALESCE(sum(p.montant), 0::numeric) AS total_montant,
       COALESCE(avg(p.montant), 0::numeric) AS montant_moyen,
       COALESCE(max(p.montant), 0::numeric) AS montant_max,
       COALESCE(min(p.montant), 0::numeric) AS montant_min
FROM agents a
         LEFT JOIN departements d ON a.id_departement = d.id_departement
         LEFT JOIN paiements p ON a.id_agent = p.id_agent
GROUP BY a.id_agent, a.nom, a.prenom, a.email, a.type_agent, d.nom;

alter table v_agent_statistics
    owner to admin;

