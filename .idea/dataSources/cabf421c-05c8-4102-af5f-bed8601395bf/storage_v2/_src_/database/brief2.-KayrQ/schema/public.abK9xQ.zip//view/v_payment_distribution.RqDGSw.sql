create view v_payment_distribution(type_paiement, nombre, total_montant, montant_moyen, pourcentage) as
SELECT type_paiement,
       count(*)                                                                      AS nombre,
       sum(montant)                                                                  AS total_montant,
       avg(montant)                                                                  AS montant_moyen,
       round(count(*)::numeric * 100.0 / ((SELECT count(*) AS count
                                           FROM paiements paiements_1))::numeric, 2) AS pourcentage
FROM paiements
GROUP BY type_paiement
ORDER BY (sum(montant)) DESC;

alter table v_payment_distribution
    owner to admin;

