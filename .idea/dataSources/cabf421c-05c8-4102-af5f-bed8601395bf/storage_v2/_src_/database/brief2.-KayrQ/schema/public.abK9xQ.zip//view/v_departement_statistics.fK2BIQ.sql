create view v_departement_statistics
            (id_departement, departement, nombre_agents, total_paiements, total_montant, montant_moyen) as
SELECT d.id_departement,
       d.nom                                AS departement,
       count(DISTINCT a.id_agent)           AS nombre_agents,
       count(p.id_paiement)                 AS total_paiements,
       COALESCE(sum(p.montant), 0::numeric) AS total_montant,
       COALESCE(avg(p.montant), 0::numeric) AS montant_moyen
FROM departements d
         LEFT JOIN agents a ON d.id_departement = a.id_departement
         LEFT JOIN paiements p ON a.id_agent = p.id_agent
GROUP BY d.id_departement, d.nom;

alter table v_departement_statistics
    owner to admin;

