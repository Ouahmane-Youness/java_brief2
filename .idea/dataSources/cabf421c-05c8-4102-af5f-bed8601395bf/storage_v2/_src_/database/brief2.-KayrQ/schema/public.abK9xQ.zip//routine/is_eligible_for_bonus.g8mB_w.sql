create function is_eligible_for_bonus(agent_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
    agent_type type_agent;
BEGIN
    SELECT type_agent INTO agent_type
    FROM agents
    WHERE id_agent = agent_id;

    RETURN agent_type IN ('RESPONSABLE_DEPARTEMENT', 'DIRECTEUR');
END;
$$;

alter function is_eligible_for_bonus(integer) owner to admin;

