create function calculate_annual_salary(agent_id integer) returns numeric
    language plpgsql
as
$$
BEGIN
    RETURN (
        SELECT COALESCE(SUM(montant), 0)
        FROM paiements
        WHERE id_agent = agent_id
          AND type_paiement = 'SALAIRE'
          AND date_paiement >= CURRENT_DATE - INTERVAL '1 year'
    );
END;
$$;

alter function calculate_annual_salary(integer) owner to admin;

